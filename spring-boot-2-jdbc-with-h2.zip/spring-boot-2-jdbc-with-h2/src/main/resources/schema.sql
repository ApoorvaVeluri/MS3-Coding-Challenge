create table student
(
   id integer not null,
   name varchar(255) not null,
   passport_number varchar(255) not null,
   primary key(id)
);
create table ms3Interview
(
   id integer  NOT NULL AUTO_INCREMENT,
   A varchar(255)  DEFAULT NULL,
   B varchar(255)  DEFAULT NULL,
   C varchar(255)  DEFAULT NULL,
   D varchar(255)  DEFAULT NULL,
   E varchar(2000)  DEFAULT NULL,
   F varchar(255)  DEFAULT NULL,
   G varchar(255)  DEFAULT NULL,
   H varchar(255)  DEFAULT NULL,
   I varchar(255)  DEFAULT NULL,
   J varchar(255) unsigned DEFAULT NULL,
   primary key(id)
);