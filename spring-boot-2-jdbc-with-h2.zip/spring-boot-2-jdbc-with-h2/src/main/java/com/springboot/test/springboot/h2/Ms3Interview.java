package com.springboot.test.springboot.h2;

public class Ms3Interview {
	private Long id;
	private String A;
	private String B;
	private String C;
	private String D;
	private String E;
	private String F;
	private String G;
	private String H;
	private String I;
	private String J;

	public Ms3Interview() {
		super();
	}


	public Ms3Interview(String A, String B,String C, String D,String E,
			String F,String G, String H,String I,String J) {
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.D = D;
		this.E = E;
		this.F = F;
		this.G = G;
		this.H = H;
		this.I = I;
		this.J = J;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getA() {
		return A;
	}

	public void setA(String a) {
		A = a;
	}

	public String getB() {
		return B;
	}

	public void setB(String b) {
		B = b;
	}

	public String getC() {
		return C;
	}

	public void setC(String c) {
		C = c;
	}

	public String getD() {
		return D;
	}

	public void setD(String d) {
		D = d;
	}

	public String getE() {
		return E;
	}

	public void setE(String e) {
		E = e;
	}

	public String getF() {
		return F;
	}

	public void setF(String f) {
		F = f;
	}

	public String getG() {
		return G;
	}

	public void setG(String g) {
		G = g;
	}

	public String isH() {
		return H;
	}

	public void setH(String h) {
		H = h;
	}

	public String isI() {
		return I;
	}

	public void setI(String i) {
		I = i;
	}

	public String getJ() {
		return J;
	}

	public void setJ(String j) {
		J = j;
	}

	@Override
	public String toString() {
		return "Ms3Interview [id=" + id + ", A=" + A + ", B=" + B + ", C=" + C + ", D=" + D + ", E=" + E + ", F=" + F
				+ ", G=" + G + ", H=" + H + ", I=" + I + ", J=" + J + "]";
	}



}
