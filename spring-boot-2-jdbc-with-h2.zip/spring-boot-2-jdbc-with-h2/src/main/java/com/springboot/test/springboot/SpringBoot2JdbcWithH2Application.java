package com.springboot.test.springboot;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.opencsv.CSVReader;
import com.springboot.test.springboot.h2.Ms3Interview;
import com.springboot.test.springboot.h2.Ms3InterviewJdbcRepository;

@SpringBootApplication
public class SpringBoot2JdbcWithH2Application implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	Ms3InterviewJdbcRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot2JdbcWithH2Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		int received=0;
		int failed = 0;
		try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("file/ms3Interview.csv");
				Reader reader = new BufferedReader(new InputStreamReader(inputStream));
				CSVReader csvReader = new CSVReader(reader);) {
			String[] nextRecord;	
			nextRecord = csvReader.readNext();
			while ((nextRecord = csvReader.readNext()) != null && nextRecord.length >1) {
				received++;
				insertdata(nextRecord,failed);
			}
		} catch (Exception e) {
			logger.error("Excpetion in the Procees ",e);
		}
		logger.info("Number of records received -> "+received);
		logger.info("Number of records successfully insterd to DB -> "+repository.getTotalRecords());
		logger.info("Number of records Failed to insterd to DB -> "+failed);

	}

	private void insertdata(String[] nextRecord,int failed){
		try{
			logger.info("Inserting -> {}",nextRecord);
			repository.insert(new Ms3Interview(validateColumn(nextRecord[0]), validateColumn(nextRecord[1]), validateColumn(nextRecord[2]), 
					validateColumn(nextRecord[3]), validateColumn(nextRecord[4]), validateColumn(nextRecord[5]),validateColumn(nextRecord[6]),
					validateColumn(nextRecord[7]), validateColumn(nextRecord[8]), validateColumn(nextRecord[9])));
		}catch(Exception e){
			failed++;
			logger.error("Excpetion in the DB Insert ",e);
		}
	}

	private String validateColumn(String column){		
		if(StringUtils.isBlank(column)){
			return null;
		}else{
			return column;
		}
	}
}
