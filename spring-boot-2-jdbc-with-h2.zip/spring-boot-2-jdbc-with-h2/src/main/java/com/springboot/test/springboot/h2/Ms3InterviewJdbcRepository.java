package com.springboot.test.springboot.h2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class Ms3InterviewJdbcRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;

	class Ms3InterviewRowMapper implements RowMapper<Ms3Interview> {
		@Override
		public Ms3Interview mapRow(ResultSet rs, int rowNum) throws SQLException {
			Ms3Interview ms3Interview = new Ms3Interview();
			ms3Interview.setId(rs.getLong("id"));
			ms3Interview.setA(rs.getString("A"));
			ms3Interview.setB(rs.getString("B"));
			ms3Interview.setC(rs.getString("C"));
			ms3Interview.setD(rs.getString("D"));
			ms3Interview.setE(rs.getString("E"));
			ms3Interview.setF(rs.getString("F"));
			ms3Interview.setG(rs.getString("G"));
			ms3Interview.setH(rs.getString("H"));
			ms3Interview.setI(rs.getString("I"));
			ms3Interview.setJ(rs.getString("J"));
			return ms3Interview;
		}
	}
	public List<Ms3Interview> findAll() {
		return jdbcTemplate.query("select * from ms3Interview", new Ms3InterviewRowMapper());
	}

	public Integer getTotalRecords() {
		return jdbcTemplate.queryForObject("select count(*) from ms3Interview", Integer.class);
	}

	public int insert(Ms3Interview ms3Interview) {
		return jdbcTemplate.update("insert into ms3Interview (A, B, C, D, E, F, G, H, I, J) " + "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
				new Object[] { ms3Interview.getA(),ms3Interview.getB(), 
						ms3Interview.getC(),ms3Interview.getD(), ms3Interview.getE(),ms3Interview.getF(),
						ms3Interview.getG(),ms3Interview.isH(), ms3Interview.isI(),ms3Interview.getJ()});
	}
}
